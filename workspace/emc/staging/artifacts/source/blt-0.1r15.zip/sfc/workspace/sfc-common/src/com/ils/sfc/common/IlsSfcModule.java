package com.ils.sfc.common;

public class IlsSfcModule {
	public static final String MODULE_ID = "com.ils.sfc";
	public static final String MODULE_NAME = "ILS-SFC";
	public static final String BLT_MODULE_ID = "BLT";  // Block-language toolkit
}
