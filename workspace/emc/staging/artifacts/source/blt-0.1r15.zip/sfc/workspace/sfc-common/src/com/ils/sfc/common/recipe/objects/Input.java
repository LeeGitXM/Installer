package com.ils.sfc.common.recipe.objects;

/**
superiorClass: sequence (the symbol S88-RECIPE-IO-DATA)
 */
public class Input extends IO {
	
	public Input(){
		// no properties at this level
	}
}
