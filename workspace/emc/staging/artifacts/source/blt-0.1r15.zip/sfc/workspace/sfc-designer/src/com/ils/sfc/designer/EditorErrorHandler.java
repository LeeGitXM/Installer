package com.ils.sfc.designer;

public interface EditorErrorHandler {
	public void handleError(String msg);
}
